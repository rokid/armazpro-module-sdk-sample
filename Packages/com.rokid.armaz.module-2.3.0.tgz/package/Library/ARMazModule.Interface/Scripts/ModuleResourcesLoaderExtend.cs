using Cysharp.Threading.Tasks;
using rokid.armaz.module;
using UnityEditor;
using UnityEngine;

public class ModuleResourcesLoaderExtend : ModuleResourcesLoaderDefault
{
    private const string TAG = "ModuleResourcesLoaderExtend";

    protected override async UniTask<AssetBundle> LoadAssetBundleAsync(string moduleIdent)
    {
#if UNITY_EDITOR
        if (ModulePackageManager.IsEditorPacakge(moduleIdent) && !EditorPrefs.GetBool(ModuleSettings.LoadFromAssetBundle))
        {
            return null;
        }
        else
#endif
        {
            return await base.LoadAssetBundleAsync(moduleIdent);
        }
    }

    /// <summary>
    /// 从指定Module里对应AssetBundle中加载指定名称资源
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="moduleIdent">Module的编号</param>
    /// <param name="assetName">资源名</param>
    /// <returns></returns>
    public override async UniTask<T> LoadAssetAsync<T>(string moduleIdent, string assetName)
    {
        string abName = ModuleConfig.ModuleBundleFileName(moduleIdent);
#if UNITY_EDITOR
        if (ModulePackageManager.IsEditorPacakge(moduleIdent) && !EditorPrefs.GetBool(ModuleSettings.LoadFromAssetBundle))
        {
            var asset = LoadAssetAsyncEditor<T>(abName, assetName);
            return asset;
        }
        else
#endif
        {
            return await base.LoadAssetAsync<T>(moduleIdent,assetName);
        }
    }


#if UNITY_EDITOR
    private T LoadAssetAsyncEditor<T>(string abName, string assetName) where T : UnityEngine.Object
    {
        Debug.Log($"{TAG} 当前模式直接加载 {assetName} 原始资源，不从AssetBundle文件中加载");
        string[] assetPaths = AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName(abName, assetName);
        if (assetPaths != null && assetPaths.Length > 0)
        {

            Debug.Log($"{TAG} 加载 {assetName} 原始资源成功，注意如果有多个同名资源，返回的是第一个名称匹配的资源");
            return AssetDatabase.LoadAssetAtPath<T>(assetPaths[0]);
        }
        else
        {
            Debug.LogError($"{TAG} 加载 {assetName} 原始资源失败");
        }

        return null;
    }
#endif
}
