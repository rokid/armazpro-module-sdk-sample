Shader "HandleRimColor"
{
    Properties
    {
        _BaseColor   ("Base Color", Color) = (0.85,0.85,0.85,1)
        _RimColor    ("Rim Color", Color) = (1,1,1,1)
        _RimPower    ("Rim Power", Range(0.5,8)) = 2
        _ShadeStrength("Shade Strength", Range(0,1)) = 0.35
        _FakeLightDir("Fake Light Dir (world)", Vector) = (0.3,0.8,0.5,0)
    }

    SubShader
    {
        Tags
        {
            "RenderType"="Opaque"
            "Queue"="Geometry"
            "RenderPipeline"="UniversalRenderPipeline"
        }

        Pass
        {
            Name "UnlitRim"
            Tags{"LightMode"="UniversalForward"}
            ZWrite On
            Cull Back
            ZTest Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS   : NORMAL;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionHCS : SV_POSITION;
                float3 normalWS    : TEXCOORD0;
                float3 viewDirWS   : TEXCOORD1;
                UNITY_VERTEX_INPUT_INSTANCE_ID
                UNITY_VERTEX_OUTPUT_STEREO
            };

            CBUFFER_START(UnityPerMaterial)
                float4 _BaseColor;
                float4 _RimColor;
                float  _RimPower;
                float  _ShadeStrength;
                float4 _FakeLightDir;
            CBUFFER_END

            Varyings vert (Attributes v)
            {
                Varyings o;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_TRANSFER_INSTANCE_ID(v,o);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);

                float3 positionWS = TransformObjectToWorld(v.positionOS.xyz);
                o.positionHCS = TransformWorldToHClip(positionWS);
                o.normalWS = normalize(TransformObjectToWorldNormal(v.normalOS));
                o.viewDirWS = normalize(GetWorldSpaceViewDir(positionWS));
                return o;
            }

            half4 frag (Varyings i) : SV_Target
            {
                float3 N = normalize(i.normalWS);
                float3 V = normalize(i.viewDirWS);
                float3 L = normalize(_FakeLightDir.xyz);

                // 半Lambert 假光源阴影
                float lambert = dot(N,L) * 0.5 + 0.5;
                float shade = lerp(1.0 - _ShadeStrength, 1.0, lambert);

                // Rim 光
                float rim = pow(1.0 - saturate(dot(N,V)), _RimPower);

                float3 finalColor = _BaseColor.rgb * shade + _RimColor.rgb * rim;
                return float4(finalColor, _BaseColor.a);
            }
            ENDHLSL
        }
    }
}
