#if MIRROR
using Mirror.Weaver;
#endif
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace rokid.armaz.module
{
    public static class CompileHelper
    {
        public static async Task<bool> Compile(string outPath, string assemblyName, BuildTarget buildTarget)
        {
            var assemblies = CompilationPipeline.GetAssemblies(AssembliesType.Player);
            foreach (var item in assemblies)
            {
                if (item.name.Equals(assemblyName))
                {
                    var dllPath = $"{outPath}/{assemblyName}.dll";
                    AssemblyBuilder builder = new AssemblyBuilder(dllPath, item.sourceFiles);
                    //builder.compilerOptions.AllowUnsafeCode = item..AllowUnsafeCode;
                    BuildTargetGroup buildTargetGroup = BuildPipeline.GetBuildTargetGroup(buildTarget);
                    builder.compilerOptions.ApiCompatibilityLevel = PlayerSettings.GetApiCompatibilityLevel(buildTargetGroup);
                    builder.additionalReferences = item.allReferences;
                    builder.flags = AssemblyBuilderFlags.None;
                    builder.referencesOptions = ReferencesOptions.UseEngineModules;
                    builder.buildTarget = buildTarget;
                    builder.buildTargetGroup = buildTargetGroup;
                    builder.excludeReferences = new string[] { item.outputPath };

                    string definesStr = PlayerSettings.GetScriptingDefineSymbolsForGroup(buildTargetGroup);
                    List<string> defines = new List<string>(definesStr.Split(';'));
                    defines.AddRange(GetDefinesFromTarget(buildTarget));
                    defines.RemoveAll(e => string.IsNullOrEmpty(e));
                    if (defines != null && defines.Count > 0)
                    {
                        builder.additionalDefines = defines.ToArray();
                    }
                    builder.compilerOptions = item.compilerOptions;
                    bool noErr = true;
                    bool buildFinished = false;
                    builder.buildFinished += (arg1, arg2) =>
                    {
                        foreach (var msg in arg2)
                        {
                            if (msg.type == CompilerMessageType.Error)
                            {
                                Debug.LogError(msg.message);
                                noErr = false;
                            }
                            else if (msg.type == CompilerMessageType.Warning)
                            {
                                Debug.LogWarning(msg.message);
                            }
                            else
                            {
                                Debug.Log(msg.message);
                            }
                        }

#if MIRROR
                        if (noErr)
                        {
                            noErr = WeaveAssembly(dllPath, item);
                        }
#endif
                        AssetDatabase.Refresh();
                        Debug.Log($"程序集： <color=yellow>{assemblyName} </color> 完成构建！");
                        buildFinished = true;
                    };

                    if (builder.Build())
                    {
                        while (!buildFinished)
                        {
                            await Task.Delay(100);
                        }
                    }
                    else
                    {
                        Debug.LogError($"Assembly {assemblyName}.dll Build Fail！");
                        noErr = false;
                    }
                    return noErr;
                }
            }
            return false;
        }

        public static string[] GetDefinesFromTarget(BuildTarget buildTarget)
        {
            switch (buildTarget)
            {
                case BuildTarget.StandaloneWindows64:
                    return new string[] { "UNITY_STANDALONE_WIN", "UNITY_STANDALONE" };
                case BuildTarget.Android:
                    return new string[] { "UNITY_ANDROID" };
                case BuildTarget.iOS:
                    return new string[] { "UNITY_IOS" };
                case BuildTarget.StandaloneOSX:
                    return new string[] { "UNITY_STANDALONE_OSX", "UNITY_STANDALONE" };
            }
            return new string[] { };
        }

#if MIRROR
        public static bool WeaveAssembly(string assemblyPath, Assembly item)
        {
            try
            {
                string[] references = item.allReferences;
                bool success = true;

                // 调用 Mirror 内部的 IL Post Processor 辅助函数
                ILPostProcessorFromFile.ILPostProcessFile(
                    assemblyPath: assemblyPath,
                    references: references,
                    OnWarning: (warning) => { Debug.LogWarning($"[Weaver] Warning: {warning}"); },
                    OnError: (error) =>
                    {
                        Debug.LogError($"[Weaver] Error: {error}");
                        success = false;
                    }
                );

                if (success)
                {
                    Debug.Log($" [Weaver] Injection Succeeded on {assemblyPath}");
                }

                return success;
            }
            catch (Exception e)
            {
                Debug.LogError($" [Weaver] Execution failed internally. Error: {e.Message}");
                return false;
            }
        }
#endif
    }
}
