namespace rokid.armaz.module
{
    /// <summary>
    /// 第三方拦截器可选基类。默认 Allow，仅需重写 OnIntercept 实现自定义拦截规则。
    /// 通过 AMP.ModuleInterceptor.Register / Unregister 接入与移除。
    /// </summary>
    public abstract class ModuleInterceptorBase : IModuleInterceptor
    {
        public virtual int Priority => 0;

        public virtual ModuleInterceptResult OnIntercept(ModuleInterceptContext context)
            => ModuleInterceptResult.Allow;
    }
}
