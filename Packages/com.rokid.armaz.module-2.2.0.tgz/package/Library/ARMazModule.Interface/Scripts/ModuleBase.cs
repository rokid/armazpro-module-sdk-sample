using System;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.Events;

namespace rokid.armaz.module
{
    /// <summary>
    /// 开发一个有脚本的Module,应该继承的基类
    /// </summary>
    public abstract class ModuleBase : MonoBehaviour
    {
        /// <summary>
        /// 定义Module的编号，框架会自动赋值,请勿修改
        /// 当有多个相同Module实例时，Ident值是相同的。
        /// </summary>
        public string Ident;

        /// <summary>
        /// Module实例唯一编号，由框架统一编号赋值,请勿修改。
        /// 多个相同Ident的Module实例Pid是不同的，具有唯一性。
        /// </summary>
        public string Pid;

        /// <summary>
        /// 要广播消息，请运行此Action
        /// 由框架统一赋值,请勿修改。
        /// </summary>
        public UnityAction<int, object> SendEvent;


        /// <summary>
        /// 要向故事引擎脚本发送消息，请运行此Action
        /// 由框架统一赋值,请勿修改。
        /// </summary>
        public UnityAction<int, object> SendEventToStory;


        /// <summary>
        /// 响应框架及其他Module触发的消息
        /// 根据sEventBase的类型，判定是什么消息，如CustomEvent，NfcEvent等
        /// </summary>
        /// <param name="sEventBase"></param>
        public virtual void OnEvent(EventBase sEventBase) { }

        /// <summary>
        /// 如果Module相主动退出，请触发此Action
        /// 框架统一赋值,请勿修改。
        /// </summary>
        public UnityAction RequestExit;

        /// <summary>
        /// Module的入口方法,一个Module必须实现的方法。
        /// 当Module被实例启动后，框架首先调用的就是该方法。
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public abstract UniTask OnEnterAsync(object param);

        /// <summary>
        /// Module的出口方法，一个Module必须实现该方法
        /// 当Module退出的时候，框架会调用该方法
        /// </summary>
        /// <returns></returns>
        public abstract UniTask OnExitAsync();
    }
}
